void push(char whichOne);
void win();
