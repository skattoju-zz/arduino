#ifndef _STRATEGY_H
#define _STRATEGY_H

void push(int);
void evade(int);
void moveForward();
void win();
void scan();
int rwContact();
int fwContact();
void attack();

#endif